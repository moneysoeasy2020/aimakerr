# goimpacket

A complete Go implementation of [Impacket](https://github.com/fortra/impacket) - 63 tools and 24 library packages for Windows network protocol interaction, Active Directory enumeration, and attack execution. Built as a native Go framework so you can compile once and run anywhere without Python dependencies.

This is a fork of [mandiant/gopacket](https://github.com/mandiant/gopacket) that
swaps the upstream `github.com/google/gopacket` dependency for the cgo-free
fork at [github.com/Mzack9999/gopacket](https://github.com/Mzack9999/gopacket),
which loads `libpcap` dynamically at runtime via
[`purego`](https://github.com/ebitengine/purego) instead of cgo. This removes
the libpcap development headers from the build-time toolchain.

> **Beta Release - Highly Experimental.** goimpacket is under active development. Core tools have been tested against Active Directory lab environments, but edge cases and protocol quirks are expected. If something isn't working, please test the same operation with Impacket side-by-side and include both outputs in your bug report. This helps us quickly identify whether it's a goimpacket-specific issue or a shared protocol limitation.

## Installation

```bash
git clone https://github.com/Mzack9999/goimpacket
cd goimpacket

# Build and install all tools as goimpacket-<toolname> on your PATH
./install.sh

# Or just build without installing
./install.sh --build-only

# Or build with make
make build
```

Requires Go 1.24.13+ and GCC
(install with `apt install build-essential` on Debian/Ubuntu/Kali,
or `yum install gcc` on RHEL/CentOS; GCC ships with the Xcode Command Line
Tools on macOS).

GCC is needed for the proxychains hooks in `pkg/transport` (see below).
The `sniff` and `split` tools no longer require `libpcap-dev` at build time -
the cgo-free `gopacket` fork loads `libpcap` dynamically with `purego` -
but you still need a `libpcap` shared library installed at runtime to use
those two tools (`apt install libpcap0.8`, `yum install libpcap`, or
`brew install libpcap`).

### Platform Support

Linux and macOS only. Native Windows builds (MSYS2/MINGW64, plain `go build`
on Windows) are **not supported** - `pkg/transport` uses libc's `connect()`
via cgo so that `LD_PRELOAD`-based proxies like proxychains can hook it,
which has no Windows equivalent. On Windows, use
[WSL](https://learn.microsoft.com/windows/wsl/install) and build from inside
the Linux environment.

To uninstall:
```bash
./install.sh --uninstall
```

## Proxychains Support

All goimpacket tools work through proxychains. Go binaries normally bypass proxychains because Go's runtime handles DNS and networking internally, skipping the `LD_PRELOAD` hooks that proxychains relies on. goimpacket works around this by linking against the system C library for network operations, allowing proxychains to intercept connections normally.

```bash
proxychains goimpacket-secretsdump 'domain/user:password@target'
proxychains goimpacket-smbclient -k -no-pass 'domain/user@dc.domain.local'
```

## Documentation

See the [Library Developer Guide](https://github.com/Mzack9999/goimpacket/wiki) for full API documentation, code examples, and architecture overview for building custom tools on top of goimpacket's 24 protocol packages.

## Tools (63)

### Remote Execution
| Tool | Description |
|------|-------------|
| **psexec** | Remote command execution via SMB service creation |
| **smbexec** | Remote command execution via SMB (stealthier than psexec) |
| **wmiexec** | Remote command execution via WMI |
| **dcomexec** | Remote command execution via DCOM |
| **atexec** | Remote command execution via Task Scheduler |

### Credential Dumping & DPAPI
| Tool | Description |
|------|-------------|
| **secretsdump** | SAM/LSA/NTDS.dit extraction and DCSync (remote + offline) |
| **dpapi** | DPAPI backup key extraction |
| **esentutl** | Offline ESE database parser (NTDS.dit) |
| **registry-read** | Offline Windows registry hive parser |

### Kerberos
| Tool | Description |
|------|-------------|
| **getTGT** | Request a TGT with password, hash, or AES key |
| **getST** | Request a service ticket with S4U2Self/S4U2Proxy |
| **GetUserSPNs** | Kerberoasting - find and request SPNs |
| **GetNPUsers** | AS-REP roasting - find accounts without pre-auth |
| **ticketer** | Golden/silver ticket forging |
| **ticketConverter** | Convert between ccache and kirbi formats |
| **describeTicket** | Parse and decrypt Kerberos tickets |
| **getPac** | Request and parse PAC information |
| **keylistattack** | KERB-KEY-LIST-REQ attack (RODC) |
| **raiseChild** | Child-to-parent domain escalation via golden ticket |

### Active Directory Enumeration
| Tool | Description |
|------|-------------|
| **GetADUsers** | Enumerate domain users via LDAP |
| **GetADComputers** | Enumerate domain computers via LDAP |
| **GetLAPSPassword** | Read LAPS passwords via LDAP |
| **findDelegation** | Find delegation configurations |
| **lookupsid** | SID brute-forcing via LSARPC |
| **samrdump** | Enumerate users via SAMR |
| **rpcdump** | Dump RPC endpoints via epmapper |
| **rpcmap** | Scan for accessible RPC interfaces |
| **net** | net user/group/computer enumeration via SAMR/LSARPC |
| **netview** | Enumerate sessions, shares, and logged-on users |
| **CheckLDAPStatus** | Check LDAP signing and channel binding requirements |
| **DumpNTLMInfo** | Dump NTLM authentication info from SMB negotiation |
| **getArch** | Detect remote OS architecture via RPC |
| **machine_role** | Detect machine role (DC, server, workstation) |

### Active Directory Attacks
| Tool | Description |
|------|-------------|
| **addcomputer** | Create/modify/delete machine accounts (SAMR + LDAP) |
| **rbcd** | Resource-Based Constrained Delegation manipulation |
| **dacledit** | Read/write DACLs on AD objects |
| **owneredit** | Read/modify object ownership |
| **samedit** | SAM account name spoofing (CVE-2021-42278/42287) |
| **badsuccessor** | BadSuccessor / backup operator escalation |
| **changepasswd** | Change/reset passwords via SAMR and LDAP |

### SMB Tools
| Tool | Description |
|------|-------------|
| **smbclient** | Interactive SMB client (shares, ls, get, put, etc.) |
| **smbserver** | SMB server for file sharing |
| **attrib** | Query/modify file attributes via SMB |
| **filetime** | Query/modify file timestamps via SMB |
| **services** | Remote service management via SVCCTL |
| **reg** | Remote registry operations via WINREG |
| **Get-GPPPassword** | Extract Group Policy Preferences passwords from SYSVOL |
| **karmaSMB** | Rogue SMB server for hash capture |

### NTLM Relay
| Tool | Description |
|------|-------------|
| **ntlmrelayx** | Full NTLM relay framework with multi-protocol support |

ntlmrelayx supports:
- **Capture servers:** SMB, HTTP/HTTPS, WCF (ADWS), RAW, RPC, WinRM
- **Relay clients:** SMB, LDAP/LDAPS, HTTP/HTTPS, MSSQL, WinRM, RPC
- **Attacks:** secretsdump, smbexec, ldapdump, RBCD delegation, ACL abuse, shadow credentials, ADCS ESC8, addcomputer, DNS manipulation, and more
- **Infrastructure:** SOCKS5 proxy with protocol-aware plugins, interactive console, REST API, multi-target round-robin, WPAD serving

### SQL Server
| Tool | Description |
|------|-------------|
| **mssqlclient** | Interactive MSSQL client with SQL/Windows/Kerberos auth |
| **mssqlinstance** | MSSQL instance discovery via SQL Browser |

### WMI
| Tool | Description |
|------|-------------|
| **wmiquery** | Interactive WMI query shell |
| **wmipersist** | WMI event subscription persistence |

### Terminal Services
| Tool | Description |
|------|-------------|
| **tstool** | Terminal Services session and process enumeration |

### Other Protocols
| Tool | Description |
|------|-------------|
| **rdp_check** | RDP authentication check |
| **mqtt_check** | MQTT authentication check |
| **exchanger** | Exchange Web Services client |

### Utilities
| Tool | Description |
|------|-------------|
| **ntfs-read** | Offline NTFS filesystem parser |
| **ping** / **ping6** | ICMP ping |
| **sniff** / **sniffer** | Network packet capture |
| **split** | Split large files |

## Authentication

All network tools support three authentication methods:

```bash
# Password
goimpacket-secretsdump 'domain/user:password@target'

# NTLM hash (pass-the-hash)
goimpacket-secretsdump -hashes ':nthash' 'domain/user@target'

# Kerberos (pass-the-ticket)
KRB5CCNAME=ticket.ccache goimpacket-secretsdump -k -no-pass 'domain/user@target'
```

### Common Flags

| Flag | Description |
|------|-------------|
| `-hashes LMHASH:NTHASH` | NTLM hash authentication (LM hash can be empty) |
| `-k` | Use Kerberos authentication |
| `-no-pass` | Don't prompt for password (use with `-k` or `-hashes`) |
| `-dc-ip IP` | IP address of the domain controller |
| `-target-ip IP` | IP address of the target (when using hostname for Kerberos) |
| `-port PORT` | Target port (defaults vary by tool) |
| `-debug` | Enable debug output |

### Quick Examples

```bash
# Dump domain hashes via DCSync
goimpacket-secretsdump 'corp.local/admin:Password1@dc01.corp.local'

# Interactive SMB shell
goimpacket-smbclient -hashes ':aabbccdd...' 'corp.local/admin@fileserver'

# Kerberoast
goimpacket-getuserspns 'corp.local/user:pass@dc01.corp.local'

# Golden ticket
goimpacket-ticketer -nthash <krbtgt_hash> -domain-sid S-1-5-21-... -domain corp.local admin

# NTLM relay with SOCKS proxy
sudo goimpacket-ntlmrelayx -t smb://target -socks

# LDAP relay for RBCD
sudo goimpacket-ntlmrelayx -t ldaps://dc01.corp.local --delegate-access
```

## Library

The `pkg/` directory contains 24 reusable protocol packages that can be imported independently.

| Package | Description |
|---------|-------------|
| **smb** | SMB2/3 client with NTLM and Kerberos auth |
| **ldap** | LDAP client with NTLM/Kerberos bind |
| **dcerpc** | DCE/RPC client + 20 service implementations (DRSUAPI, SAMR, SVCCTL, LSARPC, WINREG, NETLOGON, DCOM, TSCH, EPMAPPER, etc.) |
| **kerberos** | Kerberos client, ticket forging (golden/silver), S4U2Self/S4U2Proxy |
| **ntlm** | NTLM authentication protocol |
| **relay** | NTLM relay framework (servers, clients, attacks, SOCKS) |
| **tds** | SQL Server TDS protocol |
| **ese** | Extensible Storage Engine parser |
| **registry** | Windows registry hive parser |
| **ntfs** | NTFS filesystem parser |
| **security** | Security descriptors, ACLs, SIDs |
| **dpapi** | DPAPI structures |
| **mqtt** | MQTT protocol client |
| **session** | Target/credential parsing (`domain/user:pass@host`) |
| **flags** | Unified CLI flag framework |

## Missing Features (vs Impacket)

goimpacket aims for full Impacket parity. The following are not yet implemented:

**Relay protocol clients:**
- IMAP relay client + attack (requires Exchange/IMAP server)
- SMTP relay client (requires SMTP server)

**Relay attack modules:**
- SCCM policies/DP attacks (requires SCCM infrastructure)

**Standalone tools:**
- `ifmap.py` (DCOM interface mapping)
- `mimikatz.py` (limited Mimikatz over RPC)
- `goldenPac.py` (MS14-068 - obsolete on patched systems)
- `smbrelayx.py` (superseded by ntlmrelayx)
- `kintercept.py` (Kerberos interception)

These gaps are low priority - most require niche infrastructure to test or are obsoleted by newer techniques.

## Known Limitations

These are protocol-level limitations shared with Impacket, not goimpacket bugs:

- **SMB to LDAPS relay** fails on patched DCs due to NTLM MIC validation (post-CVE-2019-1040). Use HTTP coercion instead.
- **WinRM relay** blocked by EPA (Extended Protection for Authentication) on patched Server 2019+.
- **RPC relay attacks** (tschexec, enum-local-admins) require PKT_INTEGRITY which is unavailable in relay sessions.
- **LDAP relay to port 389** fails on DCs requiring LDAP signing. Always relay to LDAPS (port 636).

See [KNOWN_ISSUES.md](KNOWN_ISSUES.md) for detailed information on each issue and workarounds.

## Reporting Issues & Contributing

> This is a beta release. Bugs are expected, and contributions are welcome.

### Why we ask you to test with Impacket first

Because goimpacket implements the same wire protocols as Impacket, a large
fraction of "bugs" turn out to be **environmental**, not goimpacket-specific -
patched DCs, LDAP signing requirements, EPA, PKT_INTEGRITY, SMB signing,
NTLM MIC validation post-CVE-2019-1040, missing SPNs, time skew, DNS quirks,
firewall rules, and so on. Running the same operation with Impacket side by
side removes the environment from the equation:

- **If Impacket fails the same way**, the issue is almost always
  environmental and is likely already documented in
  [KNOWN_ISSUES.md](KNOWN_ISSUES.md). No bug report needed.
- **If Impacket succeeds where goimpacket fails**, that's a real goimpacket bug
  and exactly what we want to hear about.

This single triage step saves a lot of round-trips, so please don't skip it.

### Filing a bug report

1. Run the same operation with Impacket and note whether it succeeds or fails
2. Re-run goimpacket with `-debug` and capture the full output
3. **Anonymize anything sensitive before posting.** GitHub issues are public.
   Strip or replace real hostnames, IP addresses, usernames, password hashes,
   Kerberos tickets, domain names, SIDs, and any output line that could be
   tied back to a real engagement. Replacing `corp.internal` → `example.local`
   and `dc01.corp.internal` → `dc01.example.local` is fine - keep the
   structure of the data, just not the identifying values. **If in doubt,
   redact it.**
4. Open a [GitHub issue](https://github.com/Mzack9999/goimpacket/issues/new) and include:
   - Both outputs (goimpacket and Impacket), as text not screenshots, anonymized
   - The exact command line you ran (anonymized)
   - Target OS, AD functional level, and any relevant hardening
     (signing, EPA, channel binding, patch level)
   - goimpacket version / commit hash

### Feature requests

Open a [GitHub issue](https://github.com/Mzack9999/goimpacket/issues/new) describing the use case
and the Impacket equivalent (if any). If the feature is on the
"Missing Features" list above, mention which one - it helps us prioritize.

### Pull requests

PRs are welcome. Before opening one:

- Run `go build ./...`, `go vet ./...`, `gofmt -l .`, and `go test ./...`
  and make sure they all pass cleanly
- Match the existing code style in the package you're touching
- Keep changes focused - separate refactors from feature work
- For non-trivial changes, open an issue first to discuss the approach

## Why This Matters for Defenders

Threat actors are moving away from Python. Compiled Go and Rust tooling
(Sliver, BRC4, Geacon, and bespoke loaders) is increasingly replacing
Impacket in real-world intrusions. Most defensive tooling and detection
logic was built around Impacket's Python-based network behavior, and that
coverage is eroding as the attacker ecosystem shifts to compiled languages.

goimpacket exists in part to help the security community get ahead of this
shift. By providing an open-source, readable Go implementation of the
same protocols and techniques, defenders and detection engineers can:

- **Study how Go-based tooling behaves on the wire** rather than waiting
  to encounter it during an incident
- **Understand the protocol-level differences** between Go and Python
  implementations that make existing signatures less effective
- **Run realistic purple team exercises** using the same compiled,
  single-binary tooling that threat actors are adopting, rather than
  testing exclusively against Python scripts that behave differently
  at the network layer

The gap between attacker tooling and defender visibility is widest when
new tooling stays private. Open-sourcing goimpacket narrows that gap.

## Notes

- Kerberos authentication requires a valid ccache file (TGT or service ticket)
- For Kerberos, use the FQDN hostname - not an IP address
- If `KRB5CCNAME` is not set, tools will look for `<username>.ccache` in the current directory
- All tools work through proxychains
- This project is for authorized security testing and research purposes only

## License

Released under the [Apache License 2.0](LICENSE).

goimpacket is a clean Go reimplementation of [Impacket](https://github.com/fortra/impacket); see [NOTICE](NOTICE) for full third-party acknowledgments.
