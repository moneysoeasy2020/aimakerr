//
// Copyright 2021, Sander van Harmelen
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

package gitlab

import (
	"fmt"
	"net/http"
	"time"
)

type (
	SystemHooksServiceInterface interface {
		ListHooks(options ...RequestOptionFunc) ([]*Hook, *Response, error)
		GetHook(hook int64, options ...RequestOptionFunc) (*Hook, *Response, error)
		AddHook(opt *AddHookOptions, options ...RequestOptionFunc) (*Hook, *Response, error)
		TestHook(hook int64, options ...RequestOptionFunc) (*HookEvent, *Response, error)
		DeleteHook(hook int64, options ...RequestOptionFunc) (*Response, error)
	}

	// SystemHooksService handles communication with the system hooks related
	// methods of the GitLab API.
	//
	// GitLab API docs: https://docs.gitlab.com/api/system_hooks/
	SystemHooksService struct {
		client *Client
	}
)

var _ SystemHooksServiceInterface = (*SystemHooksService)(nil)

// Hook represents a GitLab system hook.
//
// GitLab API docs: https://docs.gitlab.com/api/system_hooks/
type Hook struct {
	ID                     int64      `json:"id"`
	URL                    string     `json:"url"`
	CreatedAt              *time.Time `json:"created_at"`
	PushEvents             bool       `json:"push_events"`
	TagPushEvents          bool       `json:"tag_push_events"`
	MergeRequestsEvents    bool       `json:"merge_requests_events"`
	RepositoryUpdateEvents bool       `json:"repository_update_events"`
	EnableSSLVerification  bool       `json:"enable_ssl_verification"`
}

func (h Hook) String() string {
	return Stringify(h)
}

// ListHooks gets a list of system hooks.
//
// GitLab API docs:
// https://docs.gitlab.com/api/system_hooks/#list-system-hooks
func (s *SystemHooksService) ListHooks(options ...RequestOptionFunc) ([]*Hook, *Response, error) {
	req, err := s.client.NewRequest(http.MethodGet, "hooks", nil, options)
	if err != nil {
		return nil, nil, err
	}

	var h []*Hook
	resp, err := s.client.Do(req, &h)
	if err != nil {
		return nil, resp, err
	}

	return h, resp, nil
}

// GetHook get a single system hook.
//
// GitLab API docs:
// https://docs.gitlab.com/api/system_hooks/#get-system-hook
func (s *SystemHooksService) GetHook(hook int64, options ...RequestOptionFunc) (*Hook, *Response, error) {
	u := fmt.Sprintf("hooks/%d", hook)

	req, err := s.client.NewRequest(http.MethodGet, u, nil, options)
	if err != nil {
		return nil, nil, err
	}

	var h *Hook
	resp, err := s.client.Do(req, &h)
	if err != nil {
		return nil, resp, err
	}

	return h, resp, nil
}

// AddHookOptions represents the available AddHook() options.
//
// GitLab API docs:
// https://docs.gitlab.com/api/system_hooks/#add-new-system-hook
type AddHookOptions struct {
	URL                    *string `url:"url,omitempty" json:"url,omitempty"`
	Token                  *string `url:"token,omitempty" json:"token,omitempty"`
	PushEvents             *bool   `url:"push_events,omitempty" json:"push_events,omitempty"`
	TagPushEvents          *bool   `url:"tag_push_events,omitempty" json:"tag_push_events,omitempty"`
	MergeRequestsEvents    *bool   `url:"merge_requests_events,omitempty" json:"merge_requests_events,omitempty"`
	RepositoryUpdateEvents *bool   `url:"repository_update_events,omitempty" json:"repository_update_events,omitempty"`
	EnableSSLVerification  *bool   `url:"enable_ssl_verification,omitempty" json:"enable_ssl_verification,omitempty"`
}

// AddHook adds a new system hook hook.
//
// GitLab API docs:
// https://docs.gitlab.com/api/system_hooks/#add-new-system-hook
func (s *SystemHooksService) AddHook(opt *AddHookOptions, options ...RequestOptionFunc) (*Hook, *Response, error) {
	req, err := s.client.NewRequest(http.MethodPost, "hooks", opt, options)
	if err != nil {
		return nil, nil, err
	}

	h := new(Hook)
	resp, err := s.client.Do(req, h)
	if err != nil {
		return nil, resp, err
	}

	return h, resp, nil
}

// HookEvent represents an event trigger by a GitLab system hook.
//
// GitLab API docs: https://docs.gitlab.com/api/system_hooks/
type HookEvent struct {
	EventName  string `json:"event_name"`
	Name       string `json:"name"`
	Path       string `json:"path"`
	ProjectID  int64  `json:"project_id"`
	OwnerName  string `json:"owner_name"`
	OwnerEmail string `json:"owner_email"`
}

func (h HookEvent) String() string {
	return Stringify(h)
}

// TestHook tests a system hook.
//
// GitLab API docs:
// https://docs.gitlab.com/api/system_hooks/#test-system-hook
func (s *SystemHooksService) TestHook(hook int64, options ...RequestOptionFunc) (*HookEvent, *Response, error) {
	u := fmt.Sprintf("hooks/%d", hook)

	req, err := s.client.NewRequest(http.MethodGet, u, nil, options)
	if err != nil {
		return nil, nil, err
	}

	h := new(HookEvent)
	resp, err := s.client.Do(req, h)
	if err != nil {
		return nil, resp, err
	}

	return h, resp, nil
}

// DeleteHook deletes a system hook. This is an idempotent API function and
// returns 200 OK even if the hook is not available. If the hook is deleted it
// is also returned as JSON.
//
// GitLab API docs:
// https://docs.gitlab.com/api/system_hooks/#delete-system-hook
func (s *SystemHooksService) DeleteHook(hook int64, options ...RequestOptionFunc) (*Response, error) {
	u := fmt.Sprintf("hooks/%d", hook)

	req, err := s.client.NewRequest(http.MethodDelete, u, nil, options)
	if err != nil {
		return nil, err
	}

	return s.client.Do(req, nil)
}
